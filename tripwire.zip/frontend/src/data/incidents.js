/**
 * incidents.js
 *
 * Turns the flat event stream into stateful "cases" an analyst can actually
 * work: one row per distinct offending process, carrying its own evidence
 * timeline, status, notes, and action history. Before this module, the UI
 * only ever knew about a single global `incident` (whatever panic_mode last
 * reported), so a second suspicious process — or a second run of the demo —
 * had nowhere to go. Real triage means comparing several candidate incidents
 * and choosing what to do with each one independently.
 */

let _nextCaseSeq = 1;
let _nextEntrySeq = 1;

const OPEN_STATUSES = new Set(["open", "escalated"]);

/** Severity rank used to keep an incident's headline severity at its worst-seen value. */
const SEVERITY_RANK = { Critical: 2, Warning: 1, Normal: 0 };

function higherSeverity(a, b) {
  return (SEVERITY_RANK[a] ?? 0) >= (SEVERITY_RANK[b] ?? 0) ? a : b;
}

/** Groups events that belong together: same offending process + PID. */
function groupKey(event) {
  return `${event.process}::${event.pid}`;
}

function titleFor(event) {
  return event.severity === "Critical"
    ? `Suspicious activity — ${event.process}`
    : `Elevated activity — ${event.process}`;
}

function descriptionFor(event) {
  return event.severity === "Critical"
    ? "Rapid access across multiple protected resources has triggered a detection."
    : "Touch count is elevated but hasn't crossed the critical threshold yet.";
}

/**
 * Folds one new event into the current incident list, creating a case the
 * first time a process crosses into Warning/Critical and updating it
 * (evidence, severity, timestamps) on every later touch from that same
 * process. Normal events never open or touch a case.
 *
 * Pure function: returns a new array, existing incident objects for
 * untouched cases are reused by reference so React can bail out of re-rendering them.
 */
export function foldEventIntoIncidents(incidents, event) {
  if (event.severityRaw === "info") return incidents;

  const key = groupKey(event);
  const idx = incidents.findIndex((inc) => inc.key === key && OPEN_STATUSES.has(inc.status));

  if (idx === -1) {
    const created = {
      id: `case-${_nextCaseSeq++}`,
      key,
      process: event.process,
      pid: event.pid,
      parentProcess: event.parentProcess,
      parentPid: event.parentPid,
      severity: event.severity,
      mitre: event.mitre,
      title: titleFor(event),
      description: descriptionFor(event),
      status: "open", // open | contained | dismissed | escalated
      firstSeen: event.time,
      lastSeen: event.time,
      eventIds: [event.id],
      notes: [],
      actionLog: [],
      backendDriven: false,
    };
    return [created, ...incidents];
  }

  return incidents.map((inc, i) => {
    if (i !== idx) return inc;
    return {
      ...inc,
      severity: higherSeverity(inc.severity, event.severity),
      mitre: event.mitre || inc.mitre,
      lastSeen: event.time,
      eventIds: [...inc.eventIds, event.id],
      title: higherSeverity(inc.severity, event.severity) === "Critical" ? titleFor(event) : inc.title,
    };
  });
}

/** Builds the full derived-incident list from a whole event array (used by the demo/reset paths). */
export function buildIncidentsFromEvents(events) {
  // Fold oldest-first so lastSeen/evidence order matches arrival order.
  return [...events].reverse().reduce(foldEventIntoIncidents, []);
}

export function addNote(incidents, incidentId, text) {
  const trimmed = text.trim();
  if (!trimmed) return incidents;
  return incidents.map((inc) =>
    inc.id === incidentId
      ? {
          ...inc,
          notes: [
            ...inc.notes,
            { id: `note-${_nextEntrySeq++}`, text: trimmed, ts: new Date().toLocaleTimeString() },
          ],
        }
      : inc
  );
}

// `backendSupported: true` means this action is actually wired to
// POST /action and can really suspend/kill a process (see
// useTripwireConnection.js's respondToIncident). "isolate" and "escalate"
// have no corresponding backend endpoint — the wire contract only knows
// suspend/kill/lock — so they're labeled "(logged only)" rather than
// implying a host actually got cut off the network or a ticket was filed.
export const RESPONSE_ACTIONS = {
  suspend: {
    label: "Suspend process",
    verb: "Suspend logged",
    resultStatus: "contained",
    backendSupported: true,
    before: (inc) => `${inc.process} (PID ${inc.pid}) — running`,
    after: (inc, dryRun) =>
      dryRun
        ? "Suspend logged (dry run) — process left running"
        : `${inc.process} (PID ${inc.pid}) — suspended`,
  },
  kill: {
    label: "Kill process",
    verb: "Kill logged",
    resultStatus: "contained",
    backendSupported: true,
    before: (inc) => `${inc.process} (PID ${inc.pid}) — running`,
    after: (inc, dryRun) =>
      dryRun
        ? "Kill logged (dry run) — process left running"
        : `${inc.process} (PID ${inc.pid}) — terminated`,
  },
  isolate: {
    label: "Isolate host (logged only)",
    verb: "Isolation logged",
    resultStatus: "contained",
    backendSupported: false,
    before: () => "Host — on network",
    after: () =>
      "Isolation logged — no backend endpoint exists yet, host was NOT actually cut off the network",
  },
  escalate: {
    label: "Escalate to SOC (logged only)",
    verb: "Escalation logged",
    resultStatus: "escalated",
    backendSupported: false,
    before: (inc) => `${inc.title} — unassigned`,
    after: () => "Escalated locally — no ticketing system is wired up to notify SOC",
  },
  dismiss: {
    label: "Dismiss as false positive",
    verb: "Dismissal logged",
    resultStatus: "dismissed",
    backendSupported: false,
    before: (inc) => `${inc.title} — open`,
    after: () => "Marked as false positive — no further action",
  },
};

/** Applies a response action to one incident, appending an entry to its action log. */
export function respondToIncident(incidents, incidentId, actionKey, dryRun) {
  const action = RESPONSE_ACTIONS[actionKey];
  if (!action) return { incidents, result: null };

  let result = null;

  const next = incidents.map((inc) => {
    if (inc.id !== incidentId) return inc;
    const before = action.before(inc);
    const after = action.after(inc, dryRun);
    result = { before, after, ts: new Date().toLocaleTimeString(), action: action.label };
    return {
      ...inc,
      status: action.resultStatus,
      actionLog: [
        ...inc.actionLog,
        { id: `action-${_nextEntrySeq++}`, label: action.label, before, after, ts: result.ts, dryRun },
      ],
    };
  });

  return { incidents: next, result };
}

/** Merges backend-reported panic_mode context onto the matching (by pid) open incident. */
export function attachBackendPanic(incidents, panic, lastCriticalEvent) {
  if (!lastCriticalEvent) return incidents;
  const key = `${lastCriticalEvent.process}::${lastCriticalEvent.pid}`;
  let matched = false;

  const next = incidents.map((inc) => {
    if (inc.key !== key || !OPEN_STATUSES.has(inc.status)) return inc;
    matched = true;
    return {
      ...inc,
      backendDriven: true,
      suspended: panic.suspended || [],
      killed: panic.killed ?? null,
      dryRun: panic.dry_run,
      description: panic.dry_run
        ? "Rapid access across multiple protected resources has triggered a detection. Panic Mode ran in dry-run mode — no processes were actually suspended."
        : "Rapid access across multiple protected resources has triggered a detection. Panic Mode suspended the source process and locked protected resources.",
    };
  });

  return matched ? next : incidents;
}

/** Removes a single incident from the list — e.g. an old resolved case an analyst wants off the queue. */
export function removeIncident(incidents, incidentId) {
  return incidents.filter((inc) => inc.id !== incidentId);
}

/** Bulk-removes every case that's already been resolved (contained or dismissed), leaving open/escalated work untouched. */
export function clearResolvedIncidents(incidents) {
  return incidents.filter((inc) => inc.status === "open" || inc.status === "escalated");
}

/** Sort order for the incident queue: open work first, then by severity, then most recent. */
export function sortIncidents(incidents) {
  const statusRank = { open: 0, escalated: 1, contained: 2, dismissed: 3 };
  return [...incidents].sort((a, b) => {
    if (statusRank[a.status] !== statusRank[b.status]) return statusRank[a.status] - statusRank[b.status];
    if (SEVERITY_RANK[b.severity] !== SEVERITY_RANK[a.severity])
      return (SEVERITY_RANK[b.severity] ?? 0) - (SEVERITY_RANK[a.severity] ?? 0);
    return 0;
  });
}
